# Reading trend data

data = read.csv("trend.csv")
x = data$Year
y = data$Cases_Investigated

plot(data,xlab = "Year",ylab = "Total Cases Investigaed",lwd = 3,  pch = 20)
lines(data,col = "darkred")

# Analysis
model1 = lm(y~x)
summary(model1)

model2 = lm(y~ poly(x,2,raw = TRUE) )
summary(model2)

model3 = lm(log(y)~ x )
summary(model3)

#From the fitted models it has been seen that in polynomial model fitting Multiple R-squared:  0.9943
#,Adjusted R-squared:  0.9887 are closer to each other and more closer to 1 
#So , it gives the goodness of model well.
x_axis = 2017:2021
data.frame(year = data$Year, actual = data$Cases_Investigated,
           linear = predict(model1, data.frame(x = x_axis)), 
           quad = predict(model2, data.frame(x = x_axis)),
           log_m = predict(model3, data.frame(x = x_axis)))
#Data frame shows the predicated values for different fitted models
plot(data, pch = 20, col = "blue4")
#This plot shows the increasing trend of cases
lines(data,col = "red")
m3 = function(x){
  exp(-5950382 + 1579*x)
}
curve(m3, from = 2017, to = 2025, add = TRUE, lwd = 1.5, col = "red")
library(ggplot2)
bardiag = function(df, ax, ay, cl, tit, val_lab, x_lab, y_lab ){
  bard = ggplot(data=df, aes(x = ax, y = ay ) ) +
    geom_bar(stat="identity", fill = cl,width =0.4)+ theme_classic()+
    theme(axis.text.x = element_text(angle = 90, size = 7))+ ggtitle(tit) +
    xlab(x_lab) + ylab(y_lab)
  return(bard)
}

#Plot(union territories)
#Year 2021 
#Year 2020
data1 = read.csv("utplot.csv")

Plot = bardiag(data1, ax = data1$UT, ay = data1$X_2021, "pink", 
                                  "Police cases investigated  2021", data1$X_2021, 
                                  "UNION TERRITORIES", " CASES " )
Plot
# The above figure shows that cases investigated in 2021 are more in
# delhi than the other union territories
Plot1 = bardiag(data1, ax = data1$UT, ay = data1$X_2020, "pink", 
               "Police cases  investigated 2020", data1$X_2020, 
               "UNION TERRITORIES", " CASES " )
Plot1
# The above figure shows that cases investigated in 2020 are more in
# delhi than the other union territories

#Trend(union territories)

#As higher cases investigated in Delhi so making a trend for cases in Delhi from year 2017 
#to 2021
data = read.csv("Ut_trend.csv")
x = data$Year
y = data$Investigated

plot(x,y,xlab = "year",ylab = "Cases Investigaed",main = "UNION TERRITORIE DELHI",
lwd = 3,  pch = 20)
lines(x,y,col = "darkred")

